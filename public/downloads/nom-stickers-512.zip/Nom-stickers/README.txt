Nom / Loom Studio 表情包

33 张透明 PNG，最长边 512px。全身 8 张、表情与动作 25 张。
图片不含文字；网页中的气泡仅用于试搭。

fullbody/holding-book.png — 抱书陪伴
fullbody/welcome.png — 挥手欢迎
fullbody/guide-left.png — 向左引导
fullbody/guide-right.png — 向右引导
fullbody/reading.png — 翻书阅读
fullbody/celebrating.png — 举手庆祝
fullbody/working.png — 电脑前忙碌
fullbody/resting.png — 抱书休息
bust/proud.png — 抱书得意
bust/tip.png — 举指提示
bust/thinking.png — 托腮思考
bust/thumbs-up.png — 竖拇指认可
bust/sorry.png — 合掌抱歉
bust/surprised.png — 捂嘴惊喜
bust/thank-you.png — 比心感谢
bust/gift.png — 递出礼物
bust/smile.png — 满足微笑
bust/laugh.png — 开心大笑
bust/confused.png — 困惑疑问
bust/sad.png — 委屈难过
bust/panic.png — 慌张冒汗
bust/determined.png — 认真加油
bust/sleepy.png — 困困打盹
bust/wink.png — 俏皮眨眼
bust/giggle.png — 捂嘴偷笑
bust/tsundere.png — 傲娇别扭
bust/sleeping.png — 抱枕睡觉
bust/angry.png — 气鼓鼓
bust/crying.png — 放声大哭
bust/hopeful.png — 闪亮期待
bust/love.png — 心动喜欢
bust/pudding.png — 满足吃布丁
bust/tea.png — 淡定喝茶
